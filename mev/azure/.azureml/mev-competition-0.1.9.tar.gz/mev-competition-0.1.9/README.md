## How to run

*Tested with Python 3.8.5.*

Setup python virtual environment

```shell
$ pip install virtualenv
$ virtualenv venv_mev
$ source venv_mev/bin/activate
```

Unzip repo if not already

```shell
$ unzip mev-competition-main.zip
```

Install `mev-competition` and a custom version of `EthTx`

```shell
$ cd mev-competition-main
$ pip install .
$ pip install custom_dependencies/EthTx-0.0.3.tar.gz
```

Run the show

```shell
$ python run_predict.py --input_filepath <path/to/input.csv> --output_directory <path/to/output/directory> --nodes 25
```

The path to the input csv file need to be provided in the `--input_filepath` argument and the destination directory where the submission will be saved should be provided in `--output_directory`. The `--nodes` should be set to 25.


You will be asked to enter credentials for Azure. The credentials are:

```
Email: d.hlinstak@gmail.com
Password: MevComp2021#
```

All computations are done in the Azure ML. There will be multiple pipelines submitted and the intermediate results saved (all within Azure), i.e. there will be a lot of overhead per each computation step. The process is by no means optimized for performance and depending on the sample size it can take up to several hours to produce submission. For example, it took ~7 hours to produce the submission for `test.csv` with 100k transactions. The transaction decoding takes up most time (80%).

The following steps are performed throughout the whole process:

- Divide and upload the input dataset to Azure (Local)
	- Fast

- Submit the first job to cluster
	- It takes a few minutes to spin up the cluster

- Decode (Azure ML)
	- Slowest of all steps, <500ms per transaction

- Featurize (Azure ML)
	- Quite fast, 10's of minutes tops

- Predict (Azure ML)
	- Not so fast, need to load models and perform some feature manipulation and model stacking, minutes up to an hour

- Download the `submission.csv` back to the local `output_directory `
	- Fast

If anything fails please do reach out at d.hlinstak@gmail.com
